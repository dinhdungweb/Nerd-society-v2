import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { NextRequest, NextResponse } from 'next/server'
import { differenceInMinutes } from 'date-fns'
import { generateBookingCode } from '@/lib/booking-utils'
import { audit } from '@/lib/audit'

const RESCHEDULE_BEFORE_MINUTES = 120 // Cho phép đổi lịch trước 2 tiếng

/**
 * POST /api/booking/[id]/reschedule
 * Customer reschedules their own booking (before 60 minutes of start time)
 */
export async function POST(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const session = await getServerSession(authOptions)
        if (!session?.user?.id) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
        }

        const { id } = await params
        const body = await request.json()
        const { newDate, newStartTime, newEndTime } = body

        if (!newDate || !newStartTime || !newEndTime) {
            return NextResponse.json({
                error: 'Vui lòng chọn ngày và giờ mới'
            }, { status: 400 })
        }

        // Get booking
        const booking = await prisma.booking.findUnique({
            where: { id },
            include: { room: true },
        })

        if (!booking) {
            return NextResponse.json({ error: 'Booking not found' }, { status: 404 })
        }

        // Check ownership
        if (booking.userId !== session.user.id) {
            return NextResponse.json({ error: 'Not your booking' }, { status: 403 })
        }

        if (booking.isRescheduled) {
            return NextResponse.json(
                { error: 'Bạn chỉ được đổi lịch 1 lần duy nhất.' },
                { status: 400 }
            )
        }

        // Check if can reschedule (only CONFIRMED bookings)
        if (booking.status !== 'CONFIRMED') {
            return NextResponse.json({
                error: 'Chỉ có thể đổi lịch booking đã xác nhận'
            }, { status: 400 })
        }

        // Check time - must be at least 60 minutes before current start
        const currentStart = new Date(booking.date)
        const [hours, minutes] = booking.startTime.split(':').map(Number)
        currentStart.setHours(hours, minutes, 0, 0)

        const now = new Date()
        const minutesToStart = differenceInMinutes(currentStart, now)

        if (minutesToStart < RESCHEDULE_BEFORE_MINUTES) {
            return NextResponse.json({
                error: `Chỉ có thể đổi lịch trước ${RESCHEDULE_BEFORE_MINUTES} phút. Vui lòng liên hệ staff.`
            }, { status: 400 })
        }

        // Check if new slot is available
        const newDateObj = new Date(newDate)
        const conflictingBooking = await prisma.booking.findFirst({
            where: {
                roomId: booking.roomId,
                date: newDateObj,
                status: { in: ['CONFIRMED', 'IN_PROGRESS'] },
                id: { not: booking.id },
                OR: [
                    // New booking overlaps with existing
                    {
                        startTime: { lt: newEndTime },
                        endTime: { gt: newStartTime },
                    },
                ],
            },
        })

        if (conflictingBooking) {
            return NextResponse.json({
                error: 'Khung giờ này đã có người đặt. Vui lòng chọn khung giờ khác.'
            }, { status: 409 })
        }

        // 4. Create new booking and cancel old one in a transaction
        const result = await prisma.$transaction(async (tx) => {
            // Generate NEW booking code for the NEW date
            const newBookingCode = await generateBookingCode(newDateObj);

            // a. Create new booking
            const newBooking = await tx.booking.create({
                data: {
                    bookingCode: newBookingCode,
                    roomId: booking.roomId,
                    locationId: booking.locationId,
                    date: newDateObj,
                    endDate: newDateObj,
                    startTime: newStartTime,
                    endTime: newEndTime,
                    guests: booking.guests,
                    customerName: booking.customerName,
                    customerPhone: booking.customerPhone,
                    customerEmail: booking.customerEmail,
                    userId: booking.userId,
                    status: 'CONFIRMED',
                    depositAmount: booking.depositAmount,
                    depositStatus: booking.depositStatus,
                    depositPaidAt: booking.depositPaidAt,
                    estimatedAmount: booking.estimatedAmount,
                    source: booking.source,
                    isRescheduled: true,
                    note: `[Đổi lịch từ ${booking.bookingCode} (${booking.date.toLocaleDateString('vi-VN')} ${booking.startTime})]\n${booking.note || ''}`.trim(),
                }
            });

            // b. Migrate payment to the new booking ID
            // Check if there is a payment record
            const payment = await tx.payment.findUnique({
                where: { bookingId: id }
            });

            if (payment) {
                await tx.payment.update({
                    where: { id: payment.id },
                    data: { bookingId: newBooking.id }
                });
            }

            // c. Update old booking status to CANCELLED
            await tx.booking.update({
                where: { id },
                data: {
                    status: 'CANCELLED',
                    note: `[Đã đổi lịch sang ${newBookingCode} lúc ${now.toLocaleString('vi-VN')}]\n${booking.note || ''}`.trim(),
                }
            });

            return newBooking;
        });

        // 5. Create audit log for the action
        await audit.create(
            session.user.id,
            session.user.name || session.user.email,
            'booking',
            id,
            { 
                action: 'reschedule_create_new', 
                oldBookingId: id, 
                newBookingId: result.id, 
                newDate, 
                newStartTime 
            }
        );

        return NextResponse.json({
            success: true,
            message: 'Đổi lịch thành công và đã tạo booking mới.',
            booking: {
                id: result.id,
                bookingCode: result.bookingCode,
                date: result.date,
                startTime: result.startTime,
                endTime: result.endTime,
            },
        })
    } catch (error) {
        console.error('Error rescheduling booking:', error)
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
    }
}
