import { prisma } from '@/lib/prisma'
import { ensureUserWalletAccount } from '@/lib/wallet-account'
import bcrypt from 'bcryptjs'
import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'

const registerSchema = z.object({
    name: z.string().min(2, 'Tên phải có ít nhất 2 ký tự'),
    email: z.string().email('Email không hợp lệ'),
    password: z.string().min(6, 'Mật khẩu phải có ít nhất 6 ký tự'),
    phone: z.string().optional(),
})

export async function POST(request: NextRequest) {
    try {
        const body = await request.json()
        const { name, email, password, phone } = registerSchema.parse(body)

        // Check if email already exists
        const existingUser = await prisma.user.findUnique({
            where: { email },
        })

        if (existingUser) {
            return NextResponse.json(
                { error: 'Email đã được sử dụng' },
                { status: 400 }
            )
        }

        // Check if phone already exists
        if (phone) {
            const existingPhone = await prisma.user.findFirst({
                where: { phone },
            })

            if (existingPhone) {
                return NextResponse.json(
                    { error: 'Số điện thoại đã được sử dụng bởi một tài khoản khác' },
                    { status: 400 }
                )
            }
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 12)

        // Create user
        const user = await prisma.user.create({
            data: {
                name,
                email,
                password: hashedPassword,
                phone,
                role: 'CUSTOMER',
            },
            select: {
                id: true,
                name: true,
                email: true,
                phone: true,
                role: true,
                createdAt: true,
            },
        })

        // AUTO-SYNC: Update existing guest bookings to belong to this new user
        // Find bookings with matching email OR phone AND no userId
        await prisma.booking.updateMany({
            where: {
                userId: null, // Only update guest bookings
                OR: [
                    { customerEmail: email },
                    ...(phone ? [{ customerPhone: phone }] : [])
                ]
            },
            data: {
                userId: user.id,
            },
        })

        // AUTO-SYNC: Registration Orders
        await prisma.registrationOrder.updateMany({
            where: {
                userId: null,
                OR: [
                    { email: email },
                    ...(phone ? [{ phone: phone }] : [])
                ]
            },
            data: {
                userId: user.id,
            },
        })

        // AUTO-SYNC: Subscriber Profile
        if (phone) {
            await prisma.subscriber.updateMany({
                where: {
                    userId: null,
                    phone: phone,
                },
                data: {
                    userId: user.id,
                },
            })
        }

        await ensureUserWalletAccount(user.id)

        return NextResponse.json(
            { message: 'Đăng ký thành công', user },
            { status: 201 }
        )
    } catch (error) {
        if (error instanceof z.ZodError) {
            return NextResponse.json(
                { error: error.issues[0].message },
                { status: 400 }
            )
        }

        console.error('Register error:', error)
        return NextResponse.json(
            { error: 'Đã xảy ra lỗi khi đăng ký' },
            { status: 500 }
        )
    }
}
