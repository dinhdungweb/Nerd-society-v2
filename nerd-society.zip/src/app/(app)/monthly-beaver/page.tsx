'use client';

/**
 * Trang Monthly Beaver — Đăng ký gói thành viên (Public)
 * Flow: Chọn gói → Điền info + Selfie → Thanh toán → Xác nhận
 * Phong cách: Đồng bộ với website (Light, Warm Beige Tones)
 */

import React, { useState } from 'react';

export const dynamic = 'force-dynamic';
import {
  BoltIcon,
  CheckIcon,
  CameraIcon,
  ArrowLeftIcon,
  HomeIcon,
  PhotoIcon,
  ClockIcon,
  MapPinIcon,
  ArrowRightIcon,
  CreditCardIcon,
  WalletIcon,
  LightBulbIcon,
  CheckCircleIcon,
  ClipboardDocumentListIcon,
  ArrowPathIcon,
  QrCodeIcon,
  ExclamationCircleIcon,
} from '@heroicons/react/24/outline';
import {
  CheckIcon as CheckSolidIcon,
  SparklesIcon as SparklesSolidIcon,
} from '@heroicons/react/24/solid';
import { createRegistrationOrder, payRegistrationOrderWithWallet } from '@/actions/subscription-actions';
import toast from 'react-hot-toast';
import { useSession } from 'next-auth/react';
import { useEffect, useRef } from 'react';

// Landing Page Components
import HeroSection from '@/components/monthly-beaver/HeroSection';
import FeaturesSection from '@/components/monthly-beaver/FeaturesSection';
import ComparisonSection from '@/components/monthly-beaver/ComparisonSection';
import StepsSection from '@/components/monthly-beaver/StepsSection';
import FAQSection from '@/components/monthly-beaver/FAQSection';


// ======================== TYPES ========================

type PlanType = 'WEEKLY_LIMITED' | 'MONTHLY_LIMITED' | 'MONTHLY_UNLIMITED';

type WalletSummary = {
  balance: number;
  status: string;
  walletCode: string;
};

interface PlanInfo {
  type: PlanType;
  name: string;
  price: string;
  priceNum: number;
  duration: string;
  hours: string;
  features: string[];
  popular?: boolean;
  icon: React.ReactNode;
  image?: string;
}

const PLANS: PlanInfo[] = [
  {
    type: 'MONTHLY_LIMITED',
    name: 'Gói Tháng Limited',
    price: '549.000đ',
    priceNum: 549000,
    duration: '30 ngày',
    hours: 'Max 8h/ngày',
    popular: true,
    icon: <SparklesSolidIcon className="h-5 w-5 text-primary-600" />,
    image: '/hero-banner-beaver.JPG',
    features: [
      'Priority Check-in (Tap thẻ, ngồi luôn)',
      'Inspiration Space (Có chỗ tại 2 cơ sở)',
      'Nerd Drinks (4 voucher mỗi tháng)',
      'The Essentials (Wifi, Locker, 24/7)',
    ],
  },
];

// ======================== MAIN COMPONENT ========================

export default function MonthlyBeaverPage() {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [selectedPlan, setSelectedPlan] = useState<PlanInfo | null>(null);
  const [registrationOpen, setRegistrationOpen] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    email: '',
    branchPrimary: 'HTM',
  });
  const { data: session, status } = useSession();
  const formRef = useRef<HTMLDivElement>(null);

  const scrollToForm = () => {
    formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  // Pre-fill form when session is available
  useEffect(() => {
    fetch('/api/monthly-beaver/registration-status', { cache: 'no-store' })
      .then((res) => res.json())
      .then((data) => setRegistrationOpen(data.registrationOpen === true))
      .catch(() => setRegistrationOpen(false));
  }, []);

  useEffect(() => {
    if (status === 'authenticated' && session?.user) {
      setFormData(prev => ({
        ...prev,
        fullName: prev.fullName || session.user.name || '',
        email: prev.email || session.user.email || '',
        phone: prev.phone || (session.user as any).phone || '',
      }));
    }
  }, [session, status]);

  // Scroll to top when step changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [step]);
  const [selfieUrl, setSelfieUrl] = useState<string | null>(null);
  const [selfieBlob, setSelfieBlob] = useState<Blob | null>(null);
  const [paymentMethod, setPaymentMethod] = useState('online_transfer');
  const [orderResult, setOrderResult] = useState<{ id: string; orderCode: string } | null>(null);
  const [qrUrl, setQrUrl] = useState<string>('');
  const [bankInfo, setBankInfo] = useState<{ bankCode: string; accountNumber: string; accountName: string } | null>(null);
  const [walletInfo, setWalletInfo] = useState<WalletSummary | null>(null);
  const [walletLoading, setWalletLoading] = useState(false);
  const [walletPaying, setWalletPaying] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Polling check payment status
  React.useEffect(() => {
    let interval: NodeJS.Timeout;
    if (step === 3 && orderResult?.id) {
      interval = setInterval(async () => {
        try {
          const res = await fetch(`/api/admin/subscriptions/orders?id=${orderResult.id}`);
          if (res.ok) {
            const data = await res.json();
            const order = Array.isArray(data) ? data[0] : data;
            if (order?.orderStatus === 'PAID') {
              setStep(4);
            }
          }
        } catch (err) {
          console.error('Polling error:', err);
        }
      }, 5000); // Check every 5s
    }
    return () => clearInterval(interval);
  }, [step, orderResult]);

  useEffect(() => {
    if (status !== 'authenticated') return;

    let mounted = true;
    setWalletLoading(true);

    fetch('/api/profile/wallet/summary', { cache: 'no-store' })
      .then(async (res) => {
        const data = await res.json();
        if (mounted && res.ok && data.success) {
          setWalletInfo({
            balance: data.balance,
            status: data.status,
            walletCode: data.walletCode,
          });
        }
      })
      .catch((err) => {
        console.error('Wallet summary error:', err);
      })
      .finally(() => {
        if (mounted) setWalletLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, [status]);

  // Function to create order when moving to payment step
  const handleProceedToPayment = async () => {
    setLoading(true);
    setError('');
    try {
      let uploadedSelfieUrl = '/placeholder-selfie.jpg';
      if (selfieBlob) {
        const formDataUpload = new FormData();
        formDataUpload.append('file', selfieBlob, 'selfie.jpg');
        const uploadRes = await fetch('/api/upload', {
          method: 'POST',
          body: formDataUpload,
        });
        if (uploadRes.ok) {
          const uploadData = await uploadRes.json();
          uploadedSelfieUrl = uploadData.url || uploadedSelfieUrl;
        }
      }

      const result = await createRegistrationOrder({
        fullName: formData.fullName,
        phone: formData.phone,
        email: formData.email || undefined,
        branchPrimary: formData.branchPrimary,
        planType: selectedPlan!.type,
        selfieUrl: uploadedSelfieUrl,
        paymentMethod: 'online', // Mặc định tạo đơn online để lấy QR
        userId: session?.user?.id,
      });

      if (result.success && result.order) {
        setOrderResult({ id: result.order.id, orderCode: result.order.orderCode });
        if (result.qrUrl) setQrUrl(result.qrUrl);
        if (result.bankInfo) setBankInfo(result.bankInfo);
        setStep(3);
      } else {
        setError(result.error || 'Có lỗi xảy ra');
      }
    } catch (err) {
      setError('Lỗi kết nối, vui lòng thử lại');
    } finally {
      setLoading(false);
    }
  };

  const handleWalletPayment = async () => {
    if (!orderResult?.id) {
      setError('Không tìm thấy đơn đăng ký để thanh toán');
      return;
    }

    setWalletPaying(true);
    setError('');

    try {
      const result = await payRegistrationOrderWithWallet(orderResult.id);
      if (result.success) {
        if (typeof result.currentBalance === 'number') {
          setWalletInfo((prev) => prev ? { ...prev, balance: result.currentBalance as number } : prev);
        }
        toast.success(result.message || 'Thanh toán bằng Ví Nerd thành công');
        setStep(4);
      } else {
        setError(result.error || 'Không thể thanh toán bằng Ví Nerd');
        toast.error(result.error || 'Không thể thanh toán bằng Ví Nerd');
      }
    } catch (err) {
      setError('Lỗi kết nối, vui lòng thử lại');
      toast.error('Lỗi kết nối, vui lòng thử lại');
    } finally {
      setWalletPaying(false);
    }
  };

  // ======================== LOADING CHECK ========================
  if (status === 'loading') {
    return (
      <div className="flex min-h-screen items-center justify-center bg-neutral-50">
        <ArrowPathIcon className="h-8 w-8 animate-spin text-primary-500" />
      </div>
    );
  }

  // ======================== STEP 1: LANDING PAGE + CHỌN GÓI ========================
  if (step === 1) {
    return (
      <div className="bg-white">
        {/* Landing Sections */}
        <HeroSection onRegisterClick={scrollToForm} registrationOpen={registrationOpen} />
        <FeaturesSection />
        <ComparisonSection />
        <StepsSection />
        <FAQSection />

        <div ref={formRef} className="pt-24 pb-16 px-4">
        <div className="mx-auto max-w-5xl">
          {!registrationOpen ? (
            <div className="mx-auto max-w-2xl rounded-3xl border border-amber-200 bg-amber-50 px-6 py-10 text-center">
              <ExclamationCircleIcon className="mx-auto h-12 w-12 text-amber-500" />
              <h2 className="mt-4 text-2xl font-bold text-neutral-900">Tạm ngừng nhận đăng ký mới</h2>
              <p className="mx-auto mt-3 max-w-lg text-neutral-600">
                Monthly Beaver hiện đang tạm ngừng nhận đăng ký mới. Các hội viên hiện tại vẫn sử dụng gói và quyền lợi bình thường.
              </p>
            </div>
          ) : (
          <>
          {/* Header */}
          <div className="mb-14 text-center">
            <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary-400/30 bg-primary-100 px-5 py-2 text-sm font-medium text-primary-700">
              <SparklesSolidIcon className="h-4 w-4" />
              MONTHLY BEAVER
            </span>
            <h1 className="mt-5 text-4xl font-bold text-neutral-900 md:text-5xl">
              Gói Thành Viên
            </h1>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-neutral-500">
              Đăng ký Monthly Beaver để check-in nhanh bằng thẻ, hưởng ưu đãi đặc biệt tại không gian Nerd Society.
            </p>
          </div>

          {/* Plans Grid */}
          <div className="flex justify-center">
            <div className="w-full max-w-sm">
              {PLANS.map((plan) => (
              <div
                key={plan.type}
                className={`group relative overflow-hidden rounded-3xl border bg-white transition-all duration-300 ${
                  plan.popular
                    ? 'border-primary-400'
                    : 'border-neutral-200 hover:border-primary-300'
                }`}
              >
                {plan.popular && (
                  <div className="flex items-center justify-center gap-1.5 bg-primary-500 py-2 text-center text-xs font-semibold tracking-wider text-white uppercase">
                    <SparklesSolidIcon className="h-3.5 w-3.5" />
                    Phổ biến nhất
                  </div>
                )}

                <div className="p-7">
                  <div className="mb-3 flex items-center gap-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary-100 overflow-hidden">
                      {plan.image ? (
                        <img src={plan.image} alt={plan.name} className="h-full w-full object-cover" />
                      ) : (
                        plan.icon
                      )}
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-neutral-900">{plan.name}</h3>
                      <p className="text-sm text-neutral-400">{plan.hours} · {plan.duration}</p>
                    </div>
                  </div>

                  <div className="mb-6 mt-5">
                    <span className="text-3xl font-bold text-neutral-900">{plan.price}</span>
                  </div>

                  <ul className="mb-7 space-y-2.5">
                    {plan.features.map((f, i) => (
                      <li key={i} className="flex items-start gap-2.5 text-sm text-neutral-600">
                        <CheckIcon className="mt-0.5 h-4 w-4 flex-shrink-0 text-primary-600" />
                        {f}
                      </li>
                    ))}
                  </ul>

                  <button
                    onClick={() => {
                      setSelectedPlan(plan);
                      setStep(2);
                    }}
                    className={`w-full rounded-full py-3.5 text-sm font-semibold transition-all duration-200 ${
                      plan.popular
                        ? 'bg-primary-500 text-white hover:bg-primary-600'
                        : 'border border-neutral-300 bg-white text-neutral-800 hover:border-primary-400 hover:bg-primary-50'
                    }`}
                  >
                    Chọn gói này
                  </button>
                </div>
                </div>
              ))}
            </div>
          </div>

          {/* Note */}
          <div className="mt-10 flex items-start gap-3 rounded-2xl border border-primary-200/60 bg-primary-50 p-5">
            <LightBulbIcon className="h-5 w-5 flex-shrink-0 text-primary-600 mt-0.5" />
            <p className="text-sm text-neutral-600">
              Gói bắt đầu tính từ <strong className="text-neutral-900">lần đầu bạn đến quán</strong>, không phải từ lúc mua — yên tâm đăng ký trước!
            </p>
          </div>
          </>
          )}
        </div>
      </div>
    </div>
    );
  }

  // ======================== AUTH CHECK FOR STEPS 2+ ========================
  if (status === 'unauthenticated') {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-neutral-50 px-4 py-24 text-center">
        <div className="mb-6 rounded-3xl bg-white p-8 shadow-sm border border-neutral-200 max-w-md">
           <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-amber-50">
             <ExclamationCircleIcon className="h-8 w-8 text-amber-500" />
           </div>
           <h2 className="mb-3 text-2xl font-bold text-neutral-900">Yêu cầu đăng nhập</h2>
           <p className="mb-6 text-neutral-500">Để đăng ký Monthly Beaver và quản lý quyền lợi hội viên, bạn cần có tài khoản Nerd Society trước.</p>
           <div className="flex flex-col gap-3">
             <a href="/login?callbackUrl=/monthly-beaver" className="w-full rounded-full bg-primary-500 py-3 font-semibold text-white shadow-lg hover:bg-primary-600 transition-all">Đăng nhập ngay</a>
             <a href="/signup?callbackUrl=/monthly-beaver" className="w-full rounded-full border border-neutral-300 py-3 font-semibold text-neutral-700 hover:bg-neutral-50 transition-all">Đăng ký tài khoản mới</a>
           </div>
        </div>
      </div>
    );
  }


  // ======================== STEP 2: THÔNG TIN + SELFIE ========================
  if (step === 2 && selectedPlan) {
    return (
      <div className="bg-neutral-50 pt-24 pb-12 px-4">
        <div className="mx-auto max-w-lg">
          <button onClick={() => setStep(1)} className="mb-6 flex items-center gap-1.5 text-sm text-neutral-500 hover:text-primary-600 transition-colors">
            <ArrowLeftIcon className="h-4 w-4" />
            Quay lại chọn gói
          </button>

          <div className="rounded-3xl border border-neutral-200 bg-white p-7">
            <div className="mb-6">
              <span className="inline-flex items-center gap-2 rounded-full bg-primary-100 px-4 py-1.5 text-xs font-semibold text-primary-700">
                {selectedPlan.icon}
                {selectedPlan.name} — {selectedPlan.price}
              </span>
              <h2 className="mt-4 text-2xl font-bold text-neutral-900">Thông tin đăng ký</h2>
            </div>

            {/* Form */}
            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-neutral-700">Họ tên *</label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 px-4 py-3 text-neutral-900 placeholder-neutral-400 focus:border-primary-400 focus:bg-white focus:ring-2 focus:ring-primary-200 focus:outline-none transition-all"
                  placeholder="Nguyễn Văn A"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-neutral-700">Số điện thoại *</label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 px-4 py-3 text-neutral-900 placeholder-neutral-400 focus:border-primary-400 focus:bg-white focus:ring-2 focus:ring-primary-200 focus:outline-none transition-all"
                  placeholder="0987654321"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-neutral-700">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 px-4 py-3 text-neutral-900 placeholder-neutral-400 focus:border-primary-400 focus:bg-white focus:ring-2 focus:ring-primary-200 focus:outline-none transition-all"
                  placeholder="email@example.com"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-neutral-700">Cơ sở chính *</label>
                <div className="flex gap-3">
                  {[
                    { value: 'HTM', label: 'Hồ Tùng Mậu' },
                    { value: 'TS', label: 'Tây Sơn' },
                  ].map((b) => (
                    <button
                      key={b.value}
                      onClick={() => setFormData({ ...formData, branchPrimary: b.value })}
                      className={`flex flex-1 items-center justify-center gap-2 rounded-2xl border py-3 text-sm font-medium transition-all ${
                        formData.branchPrimary === b.value
                          ? 'border-primary-400 bg-primary-50 text-primary-700'
                          : 'border-neutral-200 bg-white text-neutral-500 hover:border-neutral-300'
                      }`}
                    >
                      <MapPinIcon className="h-4 w-4" />
                      {b.label}
                    </button>
                  ))}
                </div>
                <p className="mt-1.5 text-xs text-neutral-400">Bạn có thể dùng cả 2 cơ sở</p>
              </div>

              {/* Selfie */}
              <div className="mt-6 border-t border-neutral-100 pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <CameraIcon className="h-5 w-5 text-primary-600" />
                  <h3 className="text-lg font-semibold text-neutral-900">Xác thực khuôn mặt</h3>
                </div>
                
                <p className="mb-4 text-[13px] text-amber-700 bg-amber-50/50 p-3 rounded-xl border border-amber-100">
                  📸 <strong>Vì sao cần selfie?</strong> Thẻ chỉ dùng cho riêng bạn. Ảnh giúp nhân viên nhận ra bạn khi đến quán. Ảnh chỉ lưu nội bộ và chỉ nhân viên Nerd Society mới nhìn thấy để xác nhận khi bạn check-in.
                </p>

                {selfieUrl ? (
                  <div className="text-center">
                    <img
                      src={selfieUrl}
                      alt="Selfie"
                      className="mx-auto h-48 w-48 rounded-2xl object-cover border-2 border-primary-300 shadow-sm"
                    />
                    <button
                      onClick={() => { setSelfieUrl(null); setSelfieBlob(null); }}
                      className="mt-3 inline-flex items-center gap-1.5 text-sm text-primary-600 hover:text-primary-700 font-medium transition-colors"
                    >
                      <ArrowPathIcon className="h-4 w-4" />
                      Chụp lại
                    </button>
                  </div>
                ) : (
                  <SelfieCapture
                    onCapture={(url, blob) => {
                      setSelfieUrl(url);
                      setSelfieBlob(blob);
                    }}
                  />
                )}
              </div>
            </div>

            {error && (
              <div className="mt-4 rounded-xl bg-red-50 border border-red-200 p-3 text-sm text-red-600">
                {error}
              </div>
            )}

            <button
              onClick={handleProceedToPayment}
              disabled={loading}
              className="mt-6 w-full inline-flex items-center justify-center gap-2 rounded-full bg-primary-500 py-3.5 text-sm font-semibold text-white shadow-lg shadow-primary-500/25 transition-all hover:bg-primary-600 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <ArrowPathIcon className="h-4 w-4 animate-spin" />
                  Đang xử lý...
                </>
              ) : (
                <>
                  Tiếp tục
                  <ArrowRightIcon className="h-4 w-4" />
                </>
              )}
            </button>

          </div>
        </div>
      </div>
    );
  }

  // ======================== STEP 3: THANH TOÁN ========================
  if (step === 3 && selectedPlan) {
    const walletBalance = walletInfo?.balance ?? 0;
    const walletCanPay = !!walletInfo && walletInfo.status === 'ACTIVE' && walletBalance >= selectedPlan.priceNum;
    const walletBalanceAfter = walletBalance - selectedPlan.priceNum;

    return (
      <div className="bg-neutral-50 px-4 pb-12 pt-24">
        <div className="mx-auto max-w-md">
          <button onClick={() => setStep(2)} className="mb-4 flex items-center gap-1.5 text-sm text-neutral-500 transition-colors hover:text-primary-600">
            <ArrowLeftIcon className="h-4 w-4" />
            Quay lại
          </button>

          <div className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-sm sm:p-6">
            <div className="mb-4 flex items-center gap-2">
              <CreditCardIcon className="h-5 w-5 text-primary-600" />
              <h2 className="text-xl font-bold text-neutral-900">Thanh toán</h2>
            </div>

            {/* Order summary */}
            <div className="mb-4 flex items-center justify-between rounded-2xl border border-primary-200/50 bg-primary-50 p-3.5">
              <div>
                <p className="text-xs text-neutral-500">Gói đã chọn</p>
                <p className="font-semibold text-neutral-900">{selectedPlan.name}</p>
              </div>
              <span className="text-lg font-bold text-primary-700">{selectedPlan.price}</span>
            </div>

            {/* Payment methods */}
            <div className="space-y-2.5">
              <label
                className={`flex cursor-pointer items-center gap-3 rounded-2xl border p-3.5 transition-all ${
                  paymentMethod === 'online_transfer'
                    ? 'border-primary-400 bg-primary-50/50'
                    : 'border-neutral-200 hover:border-neutral-300'
                }`}
                onClick={() => setPaymentMethod('online_transfer')}
              >
                <div className={`h-5 w-5 rounded-full border-2 flex items-center justify-center ${paymentMethod === 'online_transfer' ? 'border-primary-500' : 'border-neutral-300'}`}>
                  {paymentMethod === 'online_transfer' && <div className="h-2.5 w-2.5 rounded-full bg-primary-500" />}
                </div>
                <QrCodeIcon className="h-5 w-5 text-neutral-500" />
                <div>
                  <p className="font-medium text-neutral-900">Chuyển khoản ngay (VietQR)</p>
                  <p className="text-xs text-neutral-400">Quét mã QR để thanh toán</p>
                </div>
              </label>

              {paymentMethod === 'online_transfer' && (
                <div className="rounded-2xl border border-neutral-200 bg-neutral-50 p-3.5 text-center">
                  <div className="relative mx-auto mb-3 flex aspect-square w-full max-w-[260px] items-center justify-center overflow-hidden rounded-2xl border border-neutral-200 bg-white">
                    {qrUrl ? (
                      <img 
                        src={qrUrl}
                        alt="VietQR Payment"
                        className="h-full w-full object-contain p-2"
                      />
                    ) : (
                      <div className="flex flex-col items-center gap-2 text-neutral-400">
                        <ArrowPathIcon className="h-8 w-8 animate-spin" />
                        <span className="text-xs">Đang tạo mã QR...</span>
                      </div>
                    )}
                  </div>

                  {bankInfo && (
                    <div className="mt-3 space-y-1.5 rounded-2xl border border-neutral-200 bg-white p-3 text-left">
                      <div className="flex items-center justify-between gap-3 text-xs">
                        <span className="text-neutral-400">Ngân hàng</span>
                        <span className="font-semibold text-neutral-900">{bankInfo.bankCode}</span>
                      </div>
                      <div className="flex items-center justify-between gap-3 text-xs">
                        <span className="text-neutral-400">Số tài khoản</span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-primary-700">{bankInfo.accountNumber}</span>
                          <button 
                            onClick={() => {
                              navigator.clipboard.writeText(bankInfo.accountNumber);
                              toast.success('Đã sao chép số tài khoản');
                            }}
                            className="p-1 hover:bg-neutral-100 rounded"
                          >
                            <ClipboardDocumentListIcon className="h-4 w-4 text-neutral-400" />
                          </button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between gap-3 text-xs">
                        <span className="text-neutral-400">Chủ tài khoản</span>
                        <span className="text-right font-medium uppercase text-neutral-900">{bankInfo.accountName}</span>
                      </div>
                      <div className="flex items-center justify-between gap-3 border-t border-neutral-100 pt-1.5 text-xs">
                        <span className="text-neutral-400">Nội dung CK</span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-primary-700">{orderResult?.orderCode}</span>
                          <button 
                             onClick={() => {
                              navigator.clipboard.writeText(orderResult?.orderCode || '');
                              toast.success('Đã sao chép nội dung');
                            }}
                            className="p-1 hover:bg-neutral-100 rounded"
                          >
                            <ClipboardDocumentListIcon className="h-4 w-4 text-neutral-400" />
                          </button>
                        </div>
                      </div>

                    </div>
                  )}


                </div>
              )}

              <label
                className={`flex cursor-pointer items-center gap-3 rounded-2xl border p-3.5 transition-all ${
                  paymentMethod === 'wallet'
                    ? 'border-primary-400 bg-primary-50/50'
                    : 'border-neutral-200 hover:border-neutral-300'
                }`}
                onClick={() => setPaymentMethod('wallet')}
              >
                <div className={`h-5 w-5 rounded-full border-2 flex items-center justify-center ${paymentMethod === 'wallet' ? 'border-primary-500' : 'border-neutral-300'}`}>
                  {paymentMethod === 'wallet' && <div className="h-2.5 w-2.5 rounded-full bg-primary-500" />}
                </div>
                <WalletIcon className="h-5 w-5 text-neutral-500" />
                <div className="min-w-0 flex-1">
                  <p className="font-medium text-neutral-900">Ví Nerd</p>
                  <p className="text-xs text-neutral-400">
                    {walletLoading
                      ? 'Đang tải số dư ví...'
                      : walletInfo
                        ? `Số dư: ${walletBalance.toLocaleString()}đ`
                        : 'Không tải được số dư ví'}
                  </p>
                </div>
              </label>

              {paymentMethod === 'wallet' && (
                <div className="rounded-2xl border border-neutral-200 bg-neutral-50 p-3.5">
                  <div className="space-y-1.5 rounded-2xl border border-neutral-200 bg-white p-3 text-xs">
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-neutral-400">Số dư hiện tại</span>
                      <span className="font-semibold text-neutral-900">{walletBalance.toLocaleString()}đ</span>
                    </div>
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-neutral-400">Cần thanh toán</span>
                      <span className="font-semibold text-primary-700">{selectedPlan.priceNum.toLocaleString()}đ</span>
                    </div>
                    <div className="flex items-center justify-between gap-4 border-t border-neutral-100 pt-2">
                      <span className="text-neutral-400">Sau thanh toán</span>
                      <span className={`font-semibold ${walletCanPay ? 'text-emerald-600' : 'text-red-600'}`}>
                        {walletInfo ? `${walletBalanceAfter.toLocaleString()}đ` : '—'}
                      </span>
                    </div>
                  </div>
                  {!walletLoading && walletInfo && !walletCanPay && (
                    <p className="mt-3 rounded-xl border border-red-100 bg-red-50 p-3 text-xs font-medium text-red-600">
                      Số dư Ví Nerd không đủ để mua gói này. Vui lòng nạp thêm hoặc chọn VietQR.
                    </p>
                  )}
                </div>
              )}
            </div>

            {error && (
              <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-600">
                {error}
              </div>
            )}

              {paymentMethod === 'wallet' ? (
                <button
                  onClick={handleWalletPayment}
                  disabled={walletPaying || walletLoading || !walletCanPay}
                  className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-neutral-900 py-3.5 font-bold text-white shadow-xl transition-all hover:bg-neutral-800 disabled:cursor-not-allowed disabled:opacity-50 active:scale-[0.98]"
                >
                  {walletPaying ? (
                    <>
                      <ArrowPathIcon className="h-5 w-5 animate-spin" />
                      Đang thanh toán...
                    </>
                  ) : (
                    <>Thanh toán bằng Ví Nerd</>
                  )}
                </button>
              ) : (
                <>
                  <div className="mt-5 flex flex-col items-center gap-3">
                    <div className="flex items-center gap-2 rounded-full border border-primary-100 bg-primary-50 px-3 py-1.5">
                      <div className="h-2 w-2 rounded-full bg-primary-500" />
                      <span className="text-xs font-medium text-primary-700 italic">Đang chờ lệnh chuyển tiền...</span>
                    </div>
                    
                    <p className="max-w-[280px] text-center text-[11px] text-neutral-400">
                      Trang sẽ tự động chuyển sang bước xác nhận ngay sau khi giao dịch thành công. Đừng đóng trình duyệt nhé!
                    </p>
                  </div>
                </>
              )}

          </div>
        </div>
      </div>
    );
  }

  // ======================== STEP 4: XÁC NHẬN ========================
  if (step === 4 && selectedPlan && orderResult) {
    const branchName = formData.branchPrimary === 'HTM' ? 'Hồ Tùng Mậu' : 'Tây Sơn';

    return (
      <div className="bg-neutral-50 pt-24 pb-12 px-4">
        <div className="mx-auto max-w-lg">
          <div className="rounded-3xl border border-neutral-200 bg-white p-8 text-center shadow-sm">
            <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-full bg-green-50 border border-green-200">
              <CheckCircleIcon className="h-8 w-8 text-green-600" />
            </div>

            <h2 className="mb-2 text-2xl font-bold text-neutral-900">Đăng ký thành công!</h2>
            <p className="mb-6 text-neutral-500">Mã đơn: <span className="font-mono font-semibold text-primary-700">{orderResult.orderCode}</span></p>

            <div className="mb-6 rounded-2xl bg-neutral-50 border border-neutral-200 p-4 text-left">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-neutral-400">Gói</span>
                  <span className="font-medium text-neutral-900">{selectedPlan.name} ({selectedPlan.price})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Cơ sở</span>
                  <span className="font-medium text-neutral-900">{branchName}</span>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-primary-200/60 bg-primary-50 p-5 text-left">
              <div className="flex items-center gap-2 mb-2">
                <ClipboardDocumentListIcon className="h-4 w-4 text-primary-700" />
                <h3 className="text-sm font-semibold text-primary-700">Bước tiếp theo</h3>
              </div>
              <ul className="space-y-1.5 text-sm text-neutral-600">
                <li className="flex items-start gap-2">
                  <MapPinIcon className="h-4 w-4 flex-shrink-0 text-primary-500 mt-0.5" />
                  Ghé cơ sở <strong className="text-neutral-900">{branchName}</strong> để nhận thẻ Monthly Beaver
                </li>
                <li className="flex items-start gap-2">
                  <CheckIcon className="h-4 w-4 flex-shrink-0 text-primary-500 mt-0.5" />
                  Thẻ đã được chuẩn bị sẵn mang tên bạn
                </li>
                <li className="flex items-start gap-2">
                  <BoltIcon className="h-4 w-4 flex-shrink-0 text-primary-500 mt-0.5" />
                  Lần đầu tap thẻ vào máy = gói bắt đầu tính
                </li>
              </ul>
              <div className="flex items-center gap-1.5 mt-3 text-xs text-neutral-400">
                <ClockIcon className="h-3.5 w-3.5" />
                Hạn nhận thẻ: 30 ngày kể từ hôm nay
              </div>
            </div>

            <a
              href="/"
              className="mt-6 inline-flex items-center gap-2 rounded-full border border-neutral-300 bg-white px-8 py-2.5 text-sm font-medium text-neutral-800 transition-colors hover:bg-neutral-50 hover:border-primary-400"
            >
              <HomeIcon className="h-4 w-4" />
              Về trang chủ
            </a>
          </div>
        </div>
      </div>
    );
  }

  return null;
}

// ======================== SELFIE CAPTURE COMPONENT ========================

function SelfieCapture({ onCapture }: { onCapture: (url: string, blob: Blob) => void }) {
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const streamRef = React.useRef<MediaStream | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isCameraStarting, setIsCameraStarting] = useState(false);
  const [isVideoReady, setIsVideoReady] = useState(false);
  const [cameraError, setCameraError] = useState('');

  // Dừng camera khi component unmount.
  useEffect(() => {
    return () => {
      streamRef.current?.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    };
  }, []);

  const stopCamera = React.useCallback(() => {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    setStream(null);
    setIsVideoReady(false);
  }, []);

  // Gắn stream vào video element mỗi khi stream thay đổi hoặc video mount.
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !stream) return;

    video.srcObject = stream;
    video.play().catch((e) => {
      console.error('Video play error:', e);
      setCameraError('Trình duyệt đã cấp quyền camera nhưng không phát được hình. Vui lòng thử lại hoặc chọn ảnh.');
      stopCamera();
    });

    return () => {
      if (video.srcObject === stream) {
        video.srcObject = null;
      }
    };
  }, [stream, stopCamera]);

  const startCamera = async () => {
    setCameraError('');
    setIsCameraStarting(true);
    setIsVideoReady(false);
    stopCamera();

    if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraError('Trình duyệt chặn mở camera do kết nối không bảo mật (yêu cầu HTTPS). Vui lòng dùng nút "Chọn ảnh".');
      setIsCameraStarting(false);
      return;
    }

    try {
      let newStream: MediaStream;
      try {
        newStream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: 'user' },
            width: { ideal: 720 },
            height: { ideal: 720 },
          },
          audio: false,
        });
      } catch (fallbackErr) {
        newStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      }

      streamRef.current = newStream;
      setStream(newStream);
    } catch (err: any) {
      console.error('Camera Error:', err);
      stopCamera();
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setCameraError('Bạn đã chặn quyền truy cập camera. Vui lòng cấp quyền lại trong cài đặt trình duyệt.');
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setCameraError('Không tìm thấy thiết bị camera trên máy của bạn.');
      } else {
        setCameraError('Lỗi: ' + (err.message || 'Không thể truy cập camera. Vui lòng thử lại.'));
      }
    } finally {
      setIsCameraStarting(false);
    }
  };

  const capture = () => {
    if (!videoRef.current || !isVideoReady) return;

    const canvas = document.createElement('canvas');
    canvas.width = 500;
    canvas.height = 500;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const video = videoRef.current;
    if (!video.videoWidth || !video.videoHeight) return;

    const size = Math.min(video.videoWidth, video.videoHeight);
    const sx = (video.videoWidth - size) / 2;
    const sy = (video.videoHeight - size) / 2;
    ctx.drawImage(video, sx, sy, size, size, 0, 0, 500, 500);

    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        onCapture(url, blob);

        // Stop stream
        stopCamera();
      }
    }, 'image/jpeg', 0.85);
  };

  const handleVideoReady = () => {
    setIsVideoReady(true);
    videoRef.current?.play().catch((e) => console.error('Video play error:', e));
  };

  // Hàm handle file upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      onCapture(url, file);
    }
  };

  return (
    <div className="text-center">
      {cameraError && (
        <div className="rounded-2xl border border-red-200 bg-red-50 p-5 mb-4">
          <p className="text-sm font-medium text-red-600 mb-4">{cameraError}</p>
          <div className="flex items-center justify-center gap-3">
            <button
              onClick={startCamera}
              className="inline-flex items-center gap-2 rounded-full bg-primary-500 px-6 py-2.5 text-sm font-medium text-white shadow-lg shadow-primary-500/25 hover:bg-primary-600 transition-colors"
            >
              <ArrowPathIcon className="h-4 w-4" />
              Thử lại camera
            </button>
            <label className="inline-flex items-center gap-2 cursor-pointer rounded-full border border-neutral-300 bg-white px-6 py-2.5 text-sm text-neutral-600 hover:border-primary-400 hover:bg-primary-50 transition-colors">
              <PhotoIcon className="h-4 w-4" />
              Chọn ảnh
              <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
            </label>
          </div>
        </div>
      )}

      {/* Hiển thị video khi đang mở camera hoặc đã có stream */}
      {(isCameraStarting || stream) && !cameraError && (
        <div className="block">
          <div className="relative mx-auto h-48 w-48 overflow-hidden rounded-2xl border-2 border-primary-300 bg-black shadow-sm">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              onLoadedMetadata={handleVideoReady}
              onCanPlay={handleVideoReady}
              className="h-full w-full object-cover"
            />
            {(isCameraStarting || !isVideoReady) && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/70 text-white">
                <ArrowPathIcon className="h-6 w-6 animate-spin" />
                <span className="text-xs font-medium">Đang mở camera...</span>
              </div>
            )}
          </div>
          <div className="mt-3 flex justify-center gap-2">
            <button
              onClick={capture}
              disabled={!isVideoReady}
              className="inline-flex items-center gap-2 rounded-full bg-primary-500 px-8 py-2 text-sm font-medium text-white shadow-lg shadow-primary-500/25 hover:bg-primary-600 disabled:cursor-not-allowed disabled:opacity-50 transition-colors"
            >
              <CameraIcon className="h-4 w-4" />
              Chụp
            </button>
            <button
              onClick={stopCamera}
              className="inline-flex items-center gap-2 rounded-full border border-neutral-300 bg-white px-5 py-2 text-sm font-medium text-neutral-600 hover:border-primary-400 hover:bg-primary-50 transition-colors"
            >
              Hủy
            </button>
          </div>
          <p className="mt-2 text-xs text-neutral-400">Nhìn thẳng vào camera · Đủ ánh sáng · Không đeo khẩu trang</p>
        </div>
      )}

      {/* Nút Mở Camera khi chưa có stream và không có lỗi */}
      {!stream && !isCameraStarting && !cameraError && (
        <div className="flex items-center justify-center gap-3">
          <button
            onClick={startCamera}
            className="inline-flex items-center gap-2 rounded-full bg-primary-500 px-6 py-2.5 text-sm font-medium text-white shadow-lg shadow-primary-500/25 hover:bg-primary-600 transition-colors"
          >
            <CameraIcon className="h-4 w-4" />
            Mở camera
          </button>
          <label className="inline-flex items-center gap-2 cursor-pointer rounded-full border border-neutral-300 bg-white px-6 py-2.5 text-sm text-neutral-600 hover:border-primary-400 hover:bg-primary-50 transition-colors">
            <PhotoIcon className="h-4 w-4" />
            Chọn ảnh
            <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
          </label>
        </div>
      )}
    </div>
  );
}
