'use client'

import { CurrencyDollarIcon } from '@heroicons/react/24/outline'
import { CheckCircleIcon } from '@heroicons/react/24/solid'
import { ServiceType } from '@prisma/client'
import clsx from 'clsx'
import Image from 'next/image'

interface Service {
    id: string
    name: string
    slug: string
    type: ServiceType
    description?: string | null
    priceSmall?: number | null        // Meeting < 8 người
    priceLarge?: number | null        // Meeting >= 8 người
    priceFirstHour?: number | null    // Pod giờ đầu
    pricePerHour?: number | null      // Pod từ giờ 2
    pricingTiers?: any[] | null
    nerdCoinReward: number
    minDuration: number
    timeStep: number
    features: string[]
    icon?: string | null
    image?: string | null
}

interface ServiceSelectorProps {
    services: Service[]
    selectedServiceType: ServiceType | null
    onSelect: (service: Service) => void
    loading?: boolean
}

const serviceIcons: Record<ServiceType, React.ReactNode> = {
    MEETING: (
        <svg className="size-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
    ),
    POD_MONO: (
        <svg className="size-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
        </svg>
    ),
    POD_MULTI: (
        <svg className="size-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
        </svg>
    ),
}

function formatPrice(price: number): string {
    return new Intl.NumberFormat('vi-VN').format(price)
}

function getPriceDisplay(service: Service): string {
    if (service.type === 'MEETING') {
        const tiers = (service.pricingTiers && Array.isArray(service.pricingTiers) && service.pricingTiers.length > 0)
            ? service.pricingTiers
            : [
                { pricePerHour: 30000 },
                { pricePerHour: 100000 },
            ]
        const prices = tiers.map((t: any) => Number(t.pricePerHour) || 0)
        const minPrice = Math.min(...prices)
        const maxPrice = Math.max(...prices)
        if (minPrice === maxPrice) return `${formatPrice(minPrice)}đ/giờ`
        return `${formatPrice(minPrice)}đ - ${formatPrice(maxPrice)}đ/giờ`
    }
    return `${formatPrice(service.priceFirstHour || 0)}đ giờ đầu`
}

function getSubtitle(service: Service): string {
    switch (service.type) {
        case 'MEETING':
            return 'Phòng họp nhóm 6-20 người'
        case 'POD_MONO':
            return 'Pod làm việc cá nhân'
        case 'POD_MULTI':
            return 'Pod làm việc 2 người'
        default:
            return ''
    }
}

export default function ServiceSelector({
    services,
    selectedServiceType,
    onSelect,
    loading = false,
}: ServiceSelectorProps) {
    if (loading) {
        return (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3].map((i) => (
                    <div key={i} className="overflow-hidden rounded-xl border-2 border-transparent bg-white p-6 shadow-sm dark:bg-neutral-900">
                        {/* Icon skeleton */}
                        <div className="relative mb-4 inline-flex overflow-hidden rounded-xl bg-neutral-100 p-3 dark:bg-neutral-800">
                            <div className="size-8 rounded bg-neutral-200 dark:bg-neutral-700" />
                            <div className="absolute inset-0 -translate-x-full animate-[shimmer_1.5s_infinite] bg-gradient-to-r from-transparent via-white/20 to-transparent" />
                        </div>
                        {/* Title skeleton */}
                        <div className="h-6 w-36 rounded bg-neutral-200 dark:bg-neutral-700" />
                        <div className="mt-2 h-4 w-44 rounded bg-neutral-100 dark:bg-neutral-800" />
                        {/* Price skeleton */}
                        <div className="mt-4 h-5 w-32 rounded bg-neutral-200 dark:bg-neutral-700" />
                        {/* Badge skeleton */}
                        <div className="mt-3 h-6 w-28 rounded-full bg-neutral-100 dark:bg-neutral-800" />
                        {/* Features skeleton */}
                        <div className="mt-4 space-y-2">
                            <div className="h-3 w-24 rounded bg-neutral-100 dark:bg-neutral-800" />
                            <div className="h-3 w-32 rounded bg-neutral-100 dark:bg-neutral-800" />
                        </div>
                    </div>
                ))}
            </div>
        )
    }

    return (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {services.map((service) => {
                const isSelected = selectedServiceType === service.type
                return (
                    <div
                        key={service.id}
                        onClick={() => onSelect(service)}
                        className={clsx(
                            'group relative cursor-pointer overflow-hidden rounded-xl border-2 p-6 transition-all',
                            isSelected
                                ? 'border-primary-500 bg-primary-50 dark:border-primary-500 dark:bg-primary-900/10'
                                : 'border-transparent bg-white shadow-sm hover:border-primary-200 hover:shadow-md dark:bg-neutral-900 dark:hover:border-primary-800'
                        )}
                    >
                        {/* Image or Icon */}
                        {service.image ? (
                            <div className="relative mb-4 size-16 overflow-hidden rounded-xl">
                                <Image
                                    src={service.image}
                                    alt={service.name}
                                    fill
                                    className="object-cover"
                                />
                            </div>
                        ) : (
                            <div className={clsx(
                                'mb-4 inline-flex rounded-xl p-3 transition-colors',
                                isSelected
                                    ? 'bg-primary-100 text-primary-600 dark:bg-primary-900/30 dark:text-primary-400'
                                    : 'bg-neutral-100 text-neutral-600 dark:bg-neutral-800 dark:text-neutral-400'
                            )}>
                                {serviceIcons[service.type]}
                            </div>
                        )}

                        {/* Selected indicator */}
                        {isSelected && (
                            <div className="absolute right-4 top-4">
                                <CheckCircleIcon className="size-6 text-primary-500" />
                            </div>
                        )}

                        {/* Title & Subtitle */}
                        <h3 className={clsx(
                            'text-lg font-semibold transition-colors',
                            isSelected
                                ? 'text-primary-700 dark:text-primary-300'
                                : 'text-neutral-900 dark:text-white'
                        )}>
                            {service.name}
                        </h3>
                        <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">
                            {getSubtitle(service)}
                        </p>

                        {/* Price */}
                        <div className="mt-4 flex items-center gap-1.5 text-base font-bold text-primary-600 dark:text-primary-400">
                            <CurrencyDollarIcon className="size-5" />
                            {getPriceDisplay(service)}
                        </div>

                        {/* Meeting pricing tiers pills */}
                        {service.type === 'MEETING' && (
                            <div className="mt-2.5 flex flex-wrap gap-1.5">
                                {((service.pricingTiers && Array.isArray(service.pricingTiers) && service.pricingTiers.length > 0)
                                    ? service.pricingTiers
                                    : [
                                        { minGuests: 1, maxGuests: 1, pricePerHour: 30000, label: '1 người' },
                                        { minGuests: 2, maxGuests: 3, pricePerHour: 60000, label: '2-3 người' },
                                        { minGuests: 4, maxGuests: null, pricePerHour: 100000, label: '4+ người' }
                                    ]
                                ).map((tier: any, idx: number) => {
                                    const min = Number(tier.minGuests) || 1
                                    const max = (tier.maxGuests !== null && tier.maxGuests !== undefined && Number(tier.maxGuests) > 0) ? Number(tier.maxGuests) : null
                                    let label = String(tier.label || '').replace(/(\d+)-(\1)\s*người/g, '$1 người')
                                    if (!label || label === `${min}-${min} người`) {
                                        label = max !== null ? (min === max ? `${min} người` : `${min}-${max} người`) : `${min}+ người`
                                    }
                                    label = label.replace(/\s*\([^)]*\)/g, '')
                                    return (
                                        <span key={idx} className="rounded-md bg-neutral-100 px-2 py-0.5 text-xs text-neutral-600 dark:bg-neutral-800 dark:text-neutral-300">
                                            {label}: <strong className="text-primary-600 dark:text-primary-400">{formatPrice(tier.pricePerHour)}đ/h</strong>
                                        </span>
                                    )
                                })}
                            </div>
                        )}

                        {/* Nerd Coin badge */}
                        {service.nerdCoinReward > 0 && (
                            <div className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-yellow-100 px-3 py-1 text-xs font-medium text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300">
                                <svg className="size-4" viewBox="0 0 24 24" fill="currentColor">
                                    <circle cx="12" cy="12" r="10" fill="currentColor" opacity="0.2" />
                                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5" fill="none" />
                                    <text x="12" y="16" textAnchor="middle" fontSize="10" fontWeight="bold" fill="currentColor">N</text>
                                </svg>
                                +{service.nerdCoinReward} Nerd Coin
                            </div>
                        )}

                        {/* Features */}
                        {service.features.length > 0 && (
                            <ul className="mt-4 space-y-1.5">
                                {service.features.slice(0, 3).map((feature, idx) => (
                                    <li key={idx} className="flex items-center gap-2 text-xs text-neutral-600 dark:text-neutral-400">
                                        <span className="size-1 rounded-full bg-primary-500" />
                                        {feature}
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>
                )
            })}
        </div>
    )
}
