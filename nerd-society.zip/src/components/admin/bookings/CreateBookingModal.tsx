import React, { Fragment, useState, useEffect } from 'react'
import { Dialog, Transition } from '@headlessui/react'
import { XMarkIcon, UserIcon, PhoneIcon } from '@heroicons/react/24/outline'
import toast from 'react-hot-toast'
import TimeSelect from '../../booking/TimeSelect'
import { isRangeOverlapping, parseTimeToMinutes, calculateDurationMultiDay } from '@/lib/booking-utils'

interface CreateBookingModalProps {
    open: boolean
    setOpen: (open: boolean) => void
    onSuccess: () => void
}

interface Room {
    id: string
    name: string
    type: string
    location: { name: string }
}

interface Service {
    id: string
    type: 'MEETING' | 'POD_MONO' | 'POD_MULTI'
    priceSmall: number | null
    priceLarge: number | null
    priceFirstHour: number | null
    pricePerHour: number | null
    pricingTiers?: any[]
}

// Helper: Generate time slots
function generateTimeSlots(step: number = 30): string[] {
    const slots: string[] = []
    for (let hour = 0; hour < 24; hour++) {
        for (let minute = 0; minute < 60; minute += step) {
            slots.push(`${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`)
        }
    }
    slots.push('24:00')
    return slots
}

// Helper: Check if a time slot overlaps with booked slots
function isTimeSlotBooked(time: string, bookedSlots: any[]): boolean {
    const timeMin = parseTimeToMinutes(time)

    for (const slot of bookedSlots) {
        const startMin = parseTimeToMinutes(slot.startTime)
        const endMin = parseTimeToMinutes(slot.endTime)

        // Cross-day slot: endTime <= startTime
        if (endMin <= startMin) {
            // Slot spans midnight: booked from startTime to 24:00 AND 00:00 to endTime
            if (timeMin >= startMin || timeMin < endMin) {
                return true
            }
        } else {
            // Normal same-day slot
            if (timeMin >= startMin && timeMin < endMin) {
                return true
            }
        }
    }
    return false
}

export default function CreateBookingModal({ open, setOpen, onSuccess }: CreateBookingModalProps) {
    const [loading, setLoading] = useState(false)
    const [rooms, setRooms] = useState<Room[]>([])
    const [services, setServices] = useState<Service[]>([])
    const [estimatedPrice, setEstimatedPrice] = useState<number>(0)

    // Form State
    const [formData, setFormData] = useState({
        customerName: '',
        customerPhone: '',
        customerEmail: '',
        roomId: '',
        date: new Date().toISOString().split('T')[0],
        endDate: new Date().toISOString().split('T')[0],
        startTime: '09:00',
        endTime: '10:00',
        guests: 1,
        source: 'ONSITE',
        depositStatus: 'PAID_CASH', // Default for Walk-in is usually Paid Cash immediately
        note: ''
    })

    const [bookedSlots, setBookedSlots] = useState<any[]>([])
    const [endDayBookedSlots, setEndDayBookedSlots] = useState<any[]>([])

    // Derived state for time slots
    const selectedRoom = rooms.find(r => r.id === formData.roomId)
    const serviceType = selectedRoom?.type.startsWith('MEETING') ? 'MEETING' : 'POD'
    const timeStep = serviceType === 'MEETING' ? 30 : 15
    const allTimeSlots = generateTimeSlots(timeStep)

    useEffect(() => {
        if (open) {
            fetchRooms()
            fetchServices()
        }
    }, [open])

    // Fetch availability when date or room changes
    useEffect(() => {
        if (open && formData.roomId && formData.date) {
            fetchAvailability(formData.date, setBookedSlots)
        }
    }, [open, formData.roomId, formData.date])

    useEffect(() => {
        if (open && formData.roomId && formData.endDate && formData.endDate !== formData.date) {
            fetchAvailability(formData.endDate, setEndDayBookedSlots)
        } else {
            setEndDayBookedSlots([])
        }
    }, [open, formData.roomId, formData.endDate, formData.date])

    const fetchAvailability = async (dateStr: string, setter: (data: any[]) => void) => {
        try {
            const res = await fetch(`/api/booking/availability?roomId=${formData.roomId}&date=${dateStr}`)
            if (res.ok) {
                const data = await res.json()
                setter(data.bookedSlots || [])
            }
        } catch (error) {
            console.error(error)
        }
    }

    const fetchRooms = async () => {
        try {
            const res = await fetch('/api/admin/rooms')
            if (res.ok) {
                const data = await res.json()
                setRooms(data)
                if (data.length > 0) {
                    setFormData(prev => ({ ...prev, roomId: data[0].id }))
                }
            }
        } catch (error) {
            console.error(error)
        }
    }

    const fetchServices = async () => {
        try {
            const res = await fetch('/api/admin/services')
            if (res.ok) {
                const data = await res.json()
                setServices(data)
            }
        } catch (error) {
            console.error(error)
        }
    }

    // Calculate price when room or duration changes
    useEffect(() => {
        if (!formData.roomId || !services.length || !rooms.length || !formData.date || !formData.endDate || !formData.startTime || !formData.endTime) return

        const room = rooms.find(r => r.id === formData.roomId)
        if (!room) return

        // Map room type to service type
        const serviceType = room.type.startsWith('MEETING') ? 'MEETING'
            : room.type === 'POD_MONO' ? 'POD_MONO' : 'POD_MULTI'

        const service = services.find(s => s.type === serviceType)
        if (!service) return

        const durationMinutes = calculateDurationMultiDay(
            new Date(formData.date),
            new Date(formData.endDate),
            formData.startTime,
            formData.endTime
        )

        // Simple client-side estimation (server validation is final)
        let price = 0
        if (serviceType === 'MEETING') {
            const tiers = (service.pricingTiers && Array.isArray(service.pricingTiers) && service.pricingTiers.length > 0)
                ? service.pricingTiers
                : [
                    { minGuests: 1, maxGuests: 1, pricePerHour: 30000 },
                    { minGuests: 2, maxGuests: 3, pricePerHour: 60000 },
                    { minGuests: 4, maxGuests: null, pricePerHour: 100000 },
                ]
            const sortedTiers = [...tiers].sort((a: any, b: any) => (a.minGuests || 1) - (b.minGuests || 1))
            const matched = sortedTiers.find((t: any) => {
                const min = t.minGuests ?? 1
                const max = (t.maxGuests !== null && t.maxGuests !== undefined) ? t.maxGuests : Infinity
                return formData.guests >= min && formData.guests <= max
            })
            const chosen = matched || sortedTiers[sortedTiers.length - 1]
            const pricePerHour = Number(chosen.pricePerHour) || 0
            price = (durationMinutes / 60) * pricePerHour
        } else {
            // Pod reasoning (simplified, server handles complex blocks)
            const pricePerHour = service.pricePerHour || 0
            price = (durationMinutes / 60) * pricePerHour
        }

        setEstimatedPrice(Math.round(price))

    }, [formData, services, rooms])

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        setLoading(true)

        if (isRangeOverlapping(
            new Date(formData.date),
            formData.startTime,
            new Date(formData.endDate),
            formData.endTime,
            bookedSlots,
            endDayBookedSlots
        )) {
            toast.error('Khung giờ bị trùng lịch!')
            setLoading(false)
            return
        }

        try {
            const res = await fetch('/api/admin/bookings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            })

            const data = await res.json()

            if (!res.ok) {
                throw new Error(data.error)
            }

            toast.success('Tạo booking thành công!')
            setFormData({
                customerName: '',
                customerPhone: '',
                customerEmail: '',
                roomId: rooms[0]?.id || '',
                date: new Date().toISOString().split('T')[0],
                endDate: new Date().toISOString().split('T')[0],
                startTime: '09:00',
                endTime: '10:00',
                guests: 1,
                source: 'ONSITE',
                depositStatus: 'PAID_CASH',
                note: ''
            })
            onSuccess()
            setOpen(false)
        } catch (error: any) {
            toast.error(error.message)
        } finally {
            setLoading(false)
        }
    }

    return (
        <Transition.Root show={open} as={Fragment}>
            <Dialog as="div" className="relative z-50" onClose={setOpen}>
                <Transition.Child
                    as={Fragment}
                    enter="ease-out duration-300"
                    enterFrom="opacity-0"
                    enterTo="opacity-100"
                    leave="ease-in duration-200"
                    leaveFrom="opacity-100"
                    leaveTo="opacity-0"
                >
                    <div className="fixed inset-0 bg-neutral-900/75 transition-opacity" />
                </Transition.Child>

                <div className="fixed inset-0 z-10 overflow-y-auto">
                    <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
                        <Transition.Child
                            as={Fragment}
                            enter="ease-out duration-300"
                            enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                            enterTo="opacity-100 translate-y-0 sm:scale-100"
                            leave="ease-in duration-200"
                            leaveFrom="opacity-100 translate-y-0 sm:scale-100"
                            leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                        >
                            <Dialog.Panel className="relative transform overflow-hidden rounded-xl bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg dark:bg-neutral-900 border dark:border-neutral-800">
                                <form onSubmit={handleSubmit}>
                                    <div className="flex justify-between items-center px-6 py-4 border-b border-neutral-200 dark:border-neutral-800">
                                        <Dialog.Title as="h3" className="text-lg font-bold text-neutral-900 dark:text-white">
                                            Tạo Booking Mới (Walk-in)
                                        </Dialog.Title>
                                        <button
                                            type="button"
                                            className="text-neutral-400 hover:text-neutral-500"
                                            onClick={() => setOpen(false)}
                                        >
                                            <XMarkIcon className="size-5" />
                                        </button>
                                    </div>

                                    <div className="p-6 space-y-4">
                                        {/* Customer Info */}
                                        <div className="space-y-4">
                                            <div>
                                                <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">Tên khách</label>
                                                <div className="relative">
                                                    <input
                                                        type="text"
                                                        required
                                                        className="w-full rounded-lg pl-10 border-neutral-300 text-sm focus:border-primary-500 focus:ring-primary-500 dark:bg-neutral-800 dark:border-neutral-700"
                                                        value={formData.customerName}
                                                        onChange={e => setFormData({ ...formData, customerName: e.target.value })}
                                                    />
                                                    <UserIcon className="absolute left-3 top-2.5 size-4 text-neutral-400" />
                                                </div>
                                            </div>
                                            <div className="grid grid-cols-2 gap-4">
                                                <div>
                                                    <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">SĐT</label>
                                                    <div className="relative">
                                                        <input
                                                            type="tel"
                                                            required
                                                            className="w-full rounded-lg pl-10 border-neutral-300 text-sm focus:border-primary-500 focus:ring-primary-500 dark:bg-neutral-800 dark:border-neutral-700"
                                                            value={formData.customerPhone}
                                                            onChange={e => setFormData({ ...formData, customerPhone: e.target.value })}
                                                        />
                                                        <PhoneIcon className="absolute left-3 top-2.5 size-4 text-neutral-400" />
                                                    </div>
                                                </div>
                                                <div>
                                                    <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">Email</label>
                                                    <input
                                                        type="email"
                                                        className="w-full rounded-lg border-neutral-300 text-sm focus:border-primary-500 focus:ring-primary-500 dark:bg-neutral-800 dark:border-neutral-700"
                                                        value={formData.customerEmail}
                                                        onChange={e => setFormData({ ...formData, customerEmail: e.target.value })}
                                                    />
                                                </div>
                                            </div>
                                        </div>

                                        <div className="pt-4 border-t border-neutral-200 dark:border-neutral-700">
                                            <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">Chọn phòng</label>
                                            <select
                                                required
                                                className="w-full rounded-lg border-neutral-300 text-sm focus:border-primary-500 focus:ring-primary-500 dark:bg-neutral-800 dark:border-neutral-700"
                                                value={formData.roomId}
                                                onChange={e => setFormData({ ...formData, roomId: e.target.value })}
                                            >
                                                {rooms.map(room => (
                                                    <option key={room.id} value={room.id}>
                                                        {room.location.name} - {room.name} ({room.type})
                                                    </option>
                                                ))}
                                            </select>
                                        </div>

                                        <div className="space-y-4">
                                            <div>
                                                <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">Bắt đầu</label>
                                                <div className="grid grid-cols-5 gap-2">
                                                    <input
                                                        type="date"
                                                        required
                                                        className="col-span-3 w-full rounded-lg border-neutral-300 text-sm focus:border-primary-500 focus:ring-primary-500 dark:bg-neutral-800 dark:border-neutral-700"
                                                        value={formData.date}
                                                        onChange={e => {
                                                            const newDate = e.target.value
                                                            setFormData(prev => ({
                                                                ...prev,
                                                                date: newDate,
                                                                endDate: prev.endDate === prev.date ? newDate : prev.endDate
                                                            }))
                                                        }}
                                                    />
                                                    <div className="col-span-2">
                                                        <TimeSelect
                                                            value={formData.startTime}
                                                            onChange={val => setFormData({ ...formData, startTime: val })}
                                                            options={allTimeSlots.map(time => ({
                                                                value: time,
                                                                label: time,
                                                                disabled: isTimeSlotBooked(time, bookedSlots)
                                                            }))}
                                                            placeholder="Giờ vào"
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                            <div>
                                                <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">Kết thúc</label>
                                                <div className="grid grid-cols-5 gap-2">
                                                    <input
                                                        type="date"
                                                        required
                                                        min={formData.date}
                                                        className="col-span-3 w-full rounded-lg border-neutral-300 text-sm focus:border-primary-500 focus:ring-primary-500 dark:bg-neutral-800 dark:border-neutral-700"
                                                        value={formData.endDate}
                                                        onChange={e => setFormData({ ...formData, endDate: e.target.value })}
                                                    />
                                                    <div className="col-span-2">
                                                        <TimeSelect
                                                            value={formData.endTime}
                                                            onChange={val => setFormData({ ...formData, endTime: val })}
                                                            options={allTimeSlots.map(time => ({
                                                                value: time,
                                                                label: time,
                                                                disabled: isRangeOverlapping(
                                                                    new Date(formData.date),
                                                                    formData.startTime,
                                                                    new Date(formData.endDate),
                                                                    time,
                                                                    bookedSlots,
                                                                    endDayBookedSlots
                                                                )
                                                            }))}
                                                            placeholder="Giờ ra"
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        {selectedRoom?.type.startsWith('MEETING') && (
                                            <div>
                                                <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">Số khách</label>
                                                <input
                                                    type="number"
                                                    min="1"
                                                    required
                                                    className="w-24 rounded-lg border-neutral-300 text-sm focus:border-primary-500 focus:ring-primary-500 dark:bg-neutral-800 dark:border-neutral-700"
                                                    value={formData.guests}
                                                    onChange={e => setFormData({ ...formData, guests: parseInt(e.target.value) || 1 })}
                                                />
                                            </div>
                                        )}

                                        {/* Price Preview */}
                                        {estimatedPrice > 0 && (
                                            <div className="p-4 bg-primary-50 dark:bg-primary-900/20 rounded-lg border border-primary-200 dark:border-primary-800">
                                                <div className="flex justify-between items-center">
                                                    <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Giá dự kiến:</span>
                                                    <span className="text-lg font-bold text-primary-600 dark:text-primary-400">
                                                        {new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(estimatedPrice)}
                                                    </span>
                                                </div>
                                                <p className="text-xs text-neutral-500 mt-1">
                                                    ({(() => {
                                                        const duration = calculateDurationMultiDay(
                                                            new Date(formData.date),
                                                            new Date(formData.endDate),
                                                            formData.startTime,
                                                            formData.endTime
                                                        )
                                                        const hours = Math.floor(duration / 60)
                                                        const minutes = duration % 60
                                                        return `${hours > 0 ? `${hours} giờ ` : ''}${minutes} phút`
                                                    })()})
                                                </p>

                                                {/* Deposit amount */}
                                                {formData.depositStatus === 'PAID_CASH' && (
                                                    <div className="flex justify-between items-center mt-3 pt-3 border-t border-primary-200 dark:border-primary-800">
                                                        <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Tiền cọc (50%):</span>
                                                        <span className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
                                                            {new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(Math.round(estimatedPrice * 0.5))}
                                                        </span>
                                                    </div>
                                                )}

                                            </div>
                                        )}

                                        {/* Overlap Warning */}
                                        {isRangeOverlapping(
                                            new Date(formData.date),
                                            formData.startTime,
                                            new Date(formData.endDate),
                                            formData.endTime,
                                            bookedSlots,
                                            endDayBookedSlots
                                        ) && (
                                                <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800 text-xs text-red-600 dark:text-red-400">
                                                    ⚠️ Cảnh báo: Khung giờ này bị trùng với lịch đã có.
                                                </div>
                                            )}
                                    </div>

                                    <div className="flex justify-end gap-3 px-6 py-4 border-t border-neutral-200 bg-neutral-50 dark:border-neutral-800 dark:bg-neutral-900/50 rounded-b-xl">
                                        <button
                                            type="button"
                                            className="px-4 py-2 text-sm font-medium text-neutral-700 hover:bg-neutral-200 rounded-lg dark:text-neutral-300 dark:hover:bg-neutral-800 transition-colors"
                                            onClick={() => setOpen(false)}
                                        >
                                            Hủy
                                        </button>
                                        <button
                                            type="submit"
                                            disabled={loading || isRangeOverlapping(
                                                new Date(formData.date),
                                                formData.startTime,
                                                new Date(formData.endDate),
                                                formData.endTime,
                                                bookedSlots,
                                                endDayBookedSlots
                                            )}
                                            className="px-4 py-2 text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm"
                                        >
                                            {loading ? 'Đang tạo...' : 'Tạo Booking'}
                                        </button>
                                    </div>
                                </form>
                            </Dialog.Panel>
                        </Transition.Child>
                    </div>
                </div>
            </Dialog>
        </Transition.Root>
    )
}


